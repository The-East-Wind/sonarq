This directory contains data of embedded database (H2 Database Engine). It's recommended for tests and demos only.
